package com.company;

import java.util.Random;

/**
 * A class representing shared characteristics of organisms.
 *
 * @author David J. Barnes, Michael Kölling, Yana Popova, Amanjit Somal
 * @version 10/02/18
 */
public abstract class Organism
{
    // Whether the organism is alive or not.
    private boolean alive;

    // The organism's field.
    private Field field;
    // The organism's position in the field.
    private Location location;
    // The organism's age.
    private int age;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new organism at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Organism(Field field, Location location)
    {
        alive = true;
        age = 0;
        this.field = field;
        setLocation(location);
    }

    /**
     * Return the breeding age of this organism
     * @return The breeding age of this organism
     */
    abstract protected int getBreedingAge();

    /**
     * Return the maximum age of this organism
     * @return The maximum age of this organism
     */
    abstract protected int getMaxAge();


    /**
     * Return the max litter size of this organism
     * @return The max litter size of this organism
     */
    abstract protected int getMaxLitterSize();

    /**
     * Return the breeding probability of this organism
     * @return The breeding probability of this organism
     */
    abstract protected double getBreedingProbability();

    /**
     * Return the age of this organism
     * @return The age of this organism
     */
    public int getAge(){
        return age;
    }

    /**
     * Set the age of this organism
     * @param The age of this organism
     */
    public void setAge(int age){
        this.age = age;
    }

    /**
     * An organism can breed if it has reached the breeding age.
     * @return true if the organism can breed, false otherwise.
     */
    public boolean canBreed()  /// in Fox and Rabbit it was private
    {
        return this.age >= this.getBreedingAge();
    }

    /**
     * Increase the age. This could result in the organism's death.
     */
    public void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }

    /**
     * Check whether the organism is alive or not.
     * @return true if the organism is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the organism is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the organism's location.
     * @return The organism's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the organism at the new location in the given field.
     * @param newLocation The organism's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the organism's field.
     * @return The organism's field.
     */
    protected Field getField()
    {
        return field;
    }
}

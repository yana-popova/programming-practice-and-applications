package com.company;

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @author David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 2016.02.29 (2)
 */
public class Fox extends Animal
{
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 17;
    // The age to which a fox can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.26;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // If the animal is nocturnal or not
    private static final boolean IS_NOCTURNAL = true;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 8;
    private static final int SQUIRREL_FOOD_VALUE = 11;
    // The duration of an illness of a fox
    private static final int SICKNESS_STEPS = 4;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fox(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            super.setFoodLevel(rand.nextInt(RABBIT_FOOD_VALUE));
            super.setFoodLevel(rand.nextInt(SQUIRREL_FOOD_VALUE));
        }
        else {
            super.setAge(0);
            super.setFoodLevel(RABBIT_FOOD_VALUE);
            super.setFoodLevel(SQUIRREL_FOOD_VALUE);
        }
    }

    /**
     * Return the breeding age of this fox
     * @return The breeding age of this fox
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Return the max age of this fox
     * @return The max age of this fox
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this fox
     * @return The breeding probability of this fox
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the steps in which the fox is sick
     * @return The steps in which the fox is sick
     */
    public int getSicknessSteps(){
        return SICKNESS_STEPS;
    }

    /**
     * Return the max litter size of this fox
     * @return The max litter size of this fox
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Return if the fox is nocturnal
     * @return if the fox is nocturnal
     */
    public boolean getIsNocturnal(){
        return IS_NOCTURNAL;
    }

    /**
     * This is what the fox does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newFoxes A list to return newly born foxes.
     */
    public void act(List<Animal> newFoxes)
    {
        incrementHunger();
        getDisease().manageHealth();
        if(isAlive()) {
            giveBirth(newFoxes);
            spreadDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.

                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) {
                    rabbit.setDead();
                    setFoodLevel(RABBIT_FOOD_VALUE);
                    return where;
                }
            }
            else if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    squirrel.setDead();
                    setFoodLevel(SQUIRREL_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this fox is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Only female foxes can give birth - they mate with the first suitable adjacent male
     * @param newFoxes A list to return newly born foxes.
     */
    private void giveBirth(List<Animal> newFoxes)
    {
        // New foxes are born into adjacent locations.
        // Get a list of adjacent free locations.
        // Only female foxes can give birth - they can mate with a random male in adjacent location
        if(getIsMale() == false){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            List<Location> adjacent = field.adjacentLocations(getLocation());///
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Fox) {
                    Fox fox = (Fox) animal;
                    if(fox.getIsMale() && fox.canBreed()) {
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Fox young = new Fox(false, field, loc, randomBoolean());
                            if(randomBoolean())young.getDisease().setStepsUntilBetter(SICKNESS_STEPS); // if the randomizer gets true, we make the animal sick
                            newFoxes.add(young);
                        }
                        return; //mate with the first seen suitable fox only
                    }
                }
            }

        }
    }

    /**
     * Spread the disease to the first adjcent non-sick animal of the same kind
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fox) {
                Fox fox = (Fox) animal; //if this fox is healthy, we spread the infection, if it is alreay ill, we move on to the next one
                if(!fox.getDisease().isSick()) {
                    fox.getDisease().setStepsUntilBetter(SICKNESS_STEPS);
                    return;
                }
            }
        }
    }
}

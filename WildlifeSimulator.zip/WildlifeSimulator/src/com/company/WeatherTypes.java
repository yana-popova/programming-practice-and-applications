package com.company;

/**
 * Representations for all the valid command words for the weatherTypes
 * along with a string in a particular language.
 *
 * @author  David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 16.02.18
 */
public enum WeatherTypes
{
    // A value for each weather word along with its
    // corresponding user interface string.
    CALM("Calm"),RAINY("Rainy"), WINDY("Windy"), SNOWY("Snowy"),  FOGGY("Foggy");

    // The  weather string.
    private String weatherString;

    /**
     * Initialise with the corresponding weather string.
     * @param weatherString The weather string.
     */
    WeatherTypes(String weatherString)
    {
        this.weatherString = weatherString;
    }

    /**
     * @return The weather word as a string.
     */
    public String toString()
    {
        return weatherString;
    }
}

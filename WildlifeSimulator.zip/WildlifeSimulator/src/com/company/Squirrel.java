package com.company;

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a squirrel.
 * squirrels age, move, breed, and die.
 *
 * @author David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 21.02.2018
 */
public class Squirrel extends Animal
{
    // Characteristics shared by all squirrels (class variables).

    // The age at which a squirrel can start to breed.
    private static final int BREEDING_AGE = 16;
    // The age to which a squirrel can live.
    private static final int MAX_AGE = 110;
    // The likelihood of a squirrel breeding.
    private static final double BREEDING_PROBABILITY = 0.50;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 10;
    // If the animal is nocturnal or not
    private static final boolean IS_NOCTURNAL = false;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single piece of grass. In effect, this is the
    // number of steps a squirrel can go before it has to eat again.
    private static final int ACORN_FOOD_VALUE = 6;
    private static final int BERRIES_FOOD_VALUE = 13;
    // The duration of an illness of a squirrel
    private static final int SICKNESS_STEPS = 3;

    // Individual characteristics (instance fields).

    /**
     * Create a new squirrel. A squirrel may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the squirrel will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Squirrel(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            super.setFoodLevel(rand.nextInt(ACORN_FOOD_VALUE));
            super.setFoodLevel(rand.nextInt(BERRIES_FOOD_VALUE));
        }
        else {
            super.setAge(0);
            super.setFoodLevel(ACORN_FOOD_VALUE);
            super.setFoodLevel(BERRIES_FOOD_VALUE);
        }
    }

    /**
     * Return the breeding age of this squirrel
     * @return The breeding age of this squirrel
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Return the steps in which the squirrel is sick
     * @return The steps in which the squirrel is sick
     */
    public int getSicknessSteps(){
        return SICKNESS_STEPS;
    }

    /**
     * Return the max age of this squirrel
     * @return The max age of this squirrel
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this squirrel
     * @return The breeding probability of this squirrel
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the max litter size of this squirrel
     * @return The max litter size of this squirrel
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Return if the squirrel is nocturnal
     * @return if the squirrel is nocturnal
     */
    public boolean getIsNocturnal(){
        return IS_NOCTURNAL;
    }

    /**
     * This is what the squirrel does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newsquirrels A list to return newly born squirrels.
     */
    public void act(List<Animal> newSquirrels)
    {
        incrementHunger();
        getDisease().manageHealth();
        if(isAlive()) {
            giveBirth(newSquirrels);
            spreadDisease();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this squirrel is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Only female squirrels can give birth - they mate with the first suitable adjacent male
     * @param newsquirrels A list to return newly born squirrels.
     */
    private void giveBirth(List<Animal> newSquirrels)
    {
        // New squirrels are born into adjacent locations.
        // Get a list of adjacent free locations.
        // Only female squirrels can give birth - they can mate with a random male in adjacent location
        if(getIsMale() == false){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Squirrel) {
                    Squirrel squirrel = (Squirrel) animal;
                    if(squirrel.getIsMale() && squirrel.canBreed()) {
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Squirrel young = new Squirrel(false, field, loc, randomBoolean());
                            if(randomBoolean())young.getDisease().setStepsUntilBetter(SICKNESS_STEPS); // if the randomizer gets true, we make the animal sick
                            newSquirrels.add(young);
                        }
                        return; //mate with the first seen suitable squirrel only
                    }
                }
            }

        }
    }

    /**
     * Look for acorn adjacent to the current location.
     * Only the first piece of acorn is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Acorn) {
                Acorn acorn = (Acorn) plant;
                if(acorn.isAlive()) {
                    acorn.setDead();
                    setFoodLevel(ACORN_FOOD_VALUE);
                    return where;
                }
            }
            else if(plant instanceof Berries) {
                Berries berries = (Berries) plant;
                if(berries.isAlive()) {
                    berries.setDead();
                    setFoodLevel(BERRIES_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Spread the disease to the first adjcent non-sick animal of the same kind
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal; //if this squirrel is healthy, we spread the infection, if it is alreay ill, we move on to the next one
                if(!squirrel.getDisease().isSick()) {
                    squirrel.getDisease().setStepsUntilBetter(SICKNESS_STEPS);
                    return;
                }
            }
        }
    }
}


package com.company;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @author David J. Barnes and Michael Kölling and Amanjit Somal and Yana Popova
 * @version 22.02.2018
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 200;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 200;
    // The probability that a fox will be created in any given grid position.
    private static final double FOX_CREATION_PROBABILITY = 0.02;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;
    // The probability that a HAWK will be created in any given grid position.
    private static final double HAWK_CREATION_PROBABILITY = 0.03;
    // The probability that a rabbit will be created in any given grid position.
    private static final double RABBIT_CREATION_PROBABILITY = 0.45;
    // The probability that a squirrel will be created in any given grid position.
    private static final double SQUIRREL_CREATION_PROBABILITY = 0.36;
    // The probability that a lizard will be created in any given grid position.
    private static final double LIZARD_CREATION_PROBABILITY = 0.20;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.65;
    // The probability that an acorn will be created in any given grid position.
    private static final double ACORN_CREATION_PROBABILITY = 0.58;
    // The probability that a berry will be created in any given grid position.
    private static final double BERRIES_CREATION_PROBABILITY = 0.45;

    // List of animals in the field.
    private List<Animal> animals;
    //List of plants in the field
    private List<Plant> plants;
    // The current state of the field.
    private Field field;
    private Field sideField;
    private int sideFieldWidth, sideFieldDepth;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // A more specific counter which holds the time of the day
    private Time timeOfDay;
    // A more specific counter which holds the weather
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        field = new Field(depth, width);
        sideField = new Field(depth,width);
        sideFieldWidth = width;
        sideFieldDepth = depth;
        timeOfDay = new Time();
        weather = new Weather();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, this);

        view.setColor(Wolf.class, Color.DARK_GRAY); // wolf is dark gray
        view.setColor(Fox.class, Color.BLUE); // fox is blue
        view.setColor(Hawk.class, Color.RED); // hawk is red
        view.setColor(Rabbit.class, Color.ORANGE); // rabbit is orange
        view.setColor(Squirrel.class, Color.PINK); // squirrels is pink
        view.setColor(Lizard.class, new Color(0, 100, 0));  // lizard is Dark green
        view.setColor2(Grass.class, Color.GREEN); // grass is green
        view.setColor2(Acorn.class, new Color(102, 0, 153)); // acorn is purple
        view.setColor2(Berries.class, Color.MAGENTA); // berries are magenta

        // Setup a valid starting point.
        reset();

    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field) && view.isViable2(sideField); step++) {
            simulateOneStep();
            //delay(1000);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * animal and  plant.
     */
    public void simulateOneStep()
    {
        step++;
        timeOfDay.incrementHour();
        WeatherTypes randomWeather = weather.generateWeather();
        String weatherType = randomWeather.toString();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        // Let all animals and plants act.

        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.incrementAge();
            switch (randomWeather){
                case SNOWY:
                    break;
                case FOGGY: //foggy weather makes nocturnal animals not move
                    if(!timeOfDay.isDay()){
                        if(animal.getIsNocturnal()) break;
                    }
                case WINDY: //windy weather makes diurnal animals not move
                    if(timeOfDay.isDay()){
                        if(!animal.getIsNocturnal()) break;
                    }
                case CALM:
                default:
                    if(timeOfDay.isDay()){ //if the animal is diurnal and it is day, the animal should act
                        if(!animal.getIsNocturnal()) animal.act(newAnimals);
                    }
                    else{ //if the animal is nocturnal and it is night, the animal should act
                        if(animal.getIsNocturnal()) animal.act(newAnimals);
                    }
            }
            //TESTING USING PRINT STATEMENTS
            //System.out.println("is day: " + timeOfDay.isDay());
            //System.out.println("is male: " + animal.getIsMale());
            //System.out.println("nocturnal: " + animal.getIsNocturnal());
            //System.out.println("sick: " + animal.getDisease().isSick());
            //System.out.println("Weather: " + weatherType);

            if(! animal.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        for(Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plant = it.next();
            plant.incrementAge();
            switch (randomWeather){
                case SNOWY:
                    break;
                default:
                    plant.act(newPlants);
            }
            if(!plant.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born plants to the main lists.
        plants.addAll(newPlants);

        view.showStatus(step, field, timeOfDay.getHour(), timeOfDay.dayOrNight(), weatherType);
        view.showStatusSide(sideField);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        timeOfDay.setHour(0);
        animals.clear();
        plants.clear();
        populate();
        String weatherType = weather.generateWeather().toString();

        // Show the starting state in the view.
        view.showStatus(step, field, timeOfDay.getHour(), timeOfDay.dayOrNight(), weatherType);
        view.showStatusSide(sideField);
    }

    //TESTING
    /**
     * Generate an random integer - 0 or 1 for the gender of the animal.
     */
    public boolean randomGender()
    {
        boolean gender;
        Random rand = new Random();
        int randomNumber = rand.nextInt(2);
        if(randomNumber == 1) gender = true; //it's male
        else gender = false;
        return gender;
    }

    /**
     * Randomly populate the field with animals and plants.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Fox fox = new Fox(true, field, location, gender);
                    animals.add(fox);
                }
                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Wolf wolf = new Wolf(true, field, location, gender);
                    animals.add(wolf);
                }
                else if(rand.nextDouble() <= HAWK_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Hawk hawk = new Hawk(true, field, location, gender);
                    animals.add(hawk);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Rabbit rabbit = new Rabbit(true, field, location, gender);
                    animals.add(rabbit);
                }
                else if(rand.nextDouble() <= SQUIRREL_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Squirrel squirrel = new Squirrel(true, field, location, gender);
                    animals.add(squirrel);
                }
                else if(rand.nextDouble() <= LIZARD_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    boolean gender= randomGender();
                    Lizard lizard = new Lizard(true, field, location, gender);
                    animals.add(lizard);
                }
                // else leave the location empty.
            }
        }

        sideField.clear();
        for(int row = 0; row < sideField.getDepth(); row++) {
            for(int col = 0; col < sideField.getWidth(); col++) {
                if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, sideField, location);
                    plants.add(grass);
                }
                else if(rand.nextDouble() <= ACORN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Acorn acorn = new Acorn(true, sideField, location);
                    plants.add(acorn);
                }
                else if(rand.nextDouble() <= BERRIES_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Berries berries = new Berries(true, sideField, location);
                    plants.add(berries);
                }
                //else leave the location empty
            }
        }
        //System.out.println("plant's have been created");

    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
}

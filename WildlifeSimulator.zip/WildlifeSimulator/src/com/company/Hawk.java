package com.company;

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a hawk.
 * hawkes age, move, eat squirrels, and die.
 *
 * @author David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 21.02.18
 */
public class Hawk extends Animal
{
    // Characteristics shared by all hawks (class variables).

    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 160;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.30;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 12;
    // If the animal is nocturnal or not
    private static final boolean IS_NOCTURNAL = false;
    // The food value of a single squirrel. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int SQUIRREL_FOOD_VALUE = 10;
    private static final int LIZARD_FOOD_VALUE = 8;

    // The duration of an illness of a Hawk
    private static final int SICKNESS_STEPS = 5;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            super.setFoodLevel(rand.nextInt(SQUIRREL_FOOD_VALUE));
            super.setFoodLevel(rand.nextInt(LIZARD_FOOD_VALUE));
        }
        else {
            super.setAge(0);
            super.setFoodLevel(SQUIRREL_FOOD_VALUE);
            super.setFoodLevel(LIZARD_FOOD_VALUE);
        }
    }

    /**
     * Return the breeding age of this hawk
     * @return The breeding age of this hawk
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Return the steps in which the hawk is sick
     * @return The steps in which the hawk is sick
     */
    public int getSicknessSteps(){
        return SICKNESS_STEPS;
    }

    /**
     * Return the max age of this hawk
     * @return The max age of this hawk
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this hawk
     * @return The breeding probability of this hawk
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the max litter size of this hawk
     * @return The max litter size of this hawk
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Return if the hawk is nocturnal
     * @return if the hawk is nocturnal
     */
    public boolean getIsNocturnal(){
        return IS_NOCTURNAL;
    }

    /**
     * This is what the hawk does most of the time: it hunts for
     * squirrels. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newhawkes A list to return newly born hawkes.
     */
    public void act(List<Animal> newHawks)
    {
        incrementHunger();
        getDisease().manageHealth();
        if(isAlive()) {
            giveBirth(newHawks);
            spreadDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.

                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for squirrels adjacent to the current location.
     * Only the first live squirrel is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Squirrel) {
                Squirrel squirrel = (Squirrel) animal;
                if(squirrel.isAlive()) {
                    squirrel.setDead();
                    setFoodLevel(SQUIRREL_FOOD_VALUE);
                    return where;
                }
            }
            else if(animal instanceof Lizard) {
                Lizard lizard = (Lizard) animal;
                if(lizard.isAlive()) {
                    lizard.setDead();
                    setFoodLevel(LIZARD_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this hawk is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Only female hawkes can give birth - they mate with the first suitable adjacent male
     * @param newhawkes A list to return newly born hawkes.
     */
    private void giveBirth(List<Animal> newHawks)
    {
        // New hawkes are born into adjacent locations.
        // Get a list of adjacent free locations.
        // Only female hawkes can give birth - they can mate with a random male in adjacent location
        if(getIsMale() == false){
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Hawk) {
                    Hawk hawk = (Hawk) animal;
                    if(hawk.getIsMale() && hawk.canBreed()) {
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Hawk young = new Hawk(false, field, loc, randomBoolean());
                            if(randomBoolean())young.getDisease().setStepsUntilBetter(SICKNESS_STEPS); // if the randomizer gets true, we make the animal sick
                            newHawks.add(young);
                        }
                        return; //mate with the first seen suitable hawk only
                    }
                }
            }

        }
    }

    /**
     * Spread the disease to the first adjcent non-sick animal of the same kind
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hawk) {
                Hawk hawk = (Hawk) animal; //if this hawk is healthy, we spread the infection, if it is alreay ill, we move on to the next one
                if(!hawk.getDisease().isSick()) {
                    hawk.getDisease().setStepsUntilBetter(SICKNESS_STEPS);
                    return;
                }
            }
        }
    }
}

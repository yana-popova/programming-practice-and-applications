/**
 * Keeps track of the time the animal has left to be sick.
 *
 * @author Amanjit Somal and Yana Popova
 * @version 20/02/18
 */
public class Disease
{
    private int stepsUntilBetter;

    /**
     * Constructor for objects of class Disease
     */
    public Disease(int steps)
    {
        stepsUntilBetter = steps;
    }
    
    /**
     * Set the steps
     * @param steps The steps the animal has left to be sick
     */
    public void setStepsUntilBetter(int steps)
    {
        stepsUntilBetter = steps;
    }

    /**
     * Return the number of steps it has until it gets better
     * @return the number of steps it has until it gets better
     */
    public int getStepsUntilBetter(){
        return stepsUntilBetter;
    }
    
    /**
     * Decrement the number of steps it has until it gets better
     */
    public void decrementSteps(){
        stepsUntilBetter--;
    }
    
    /**
     * Checks if the animal is sick
     * @return If the animal is sick
     */
    public boolean isSick()
    {
        if(stepsUntilBetter>0) return true;
        return false;
    }
    
    /**
     * Manages the health of the animal - if it is sick, it should get better
     */
    public void manageHealth(){
        if(isSick()){
            decrementSteps();
        }
    }
}

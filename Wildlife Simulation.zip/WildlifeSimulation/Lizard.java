import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a lizard.
 * lizards age, move, breed, and die.
 * 
 * @author David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 2016.02.29 (2)
 */
public class Lizard extends Animal
{
    // Characteristics shared by all lizards (class variables).

    // The age at which a lizard can start to breed.
    private static final int BREEDING_AGE =18;
    // The age to which a lizard can live.
    private static final int MAX_AGE = 105;
    // The likelihood of a lizard breeding.
    private static final double BREEDING_PROBABILITY = 0.38;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    // If the animal is nocturnal or not
    private static final boolean IS_NOCTURNAL = false;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The food value of a single piece of grass. In effect, this is the
    // number of steps a lizard can go before it has to eat again.
    private static final int BERRIES_FOOD_VALUE = 14;
    // The duration of an illness of a lizard
    private static final int SICKNESS_STEPS = 2;

    // Individual characteristics (instance fields).

    /**
     * Create a new lizard. A lizard may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the lizard will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Lizard(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            super.setFoodLevel(rand.nextInt(BERRIES_FOOD_VALUE));
        }
        else {
            super.setAge(0);
            super.setFoodLevel(BERRIES_FOOD_VALUE);
        }
    }

    /**
     * Return the steps in which the lizard is sick
     * @return The steps in which the lizard is sick
     */
    public int getSicknessSteps(){
        return SICKNESS_STEPS;
    }

    /**
     * Return the breeding age of this lizard
     * @return The breeding age of this lizard
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Return the max age of this lizard
     * @return The max age of this lizard
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this lizard
     * @return The breeding probability of this lizard
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the max litter size of this lizard
     * @return The max litter size of this lizard
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Return if the lizard is nocturnal
     * @return if the lizard is nocturnal
     */
    public boolean getIsNocturnal(){
        return IS_NOCTURNAL;
    }

    /**
     * This is what the lizard does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newlizards A list to return newly born lizards.
     */
    public void act(List<Animal> newLizards)
    {
        incrementHunger();
        getDisease().manageHealth();
        if(isAlive()) {
            giveBirth(newLizards);  
            spreadDisease();
            // Try to move into a free location.
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Check whether or not this lizard is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Only female lizards can give birth - they mate with the first suitable adjacent male
     * @param newlizards A list to return newly born lizards.
     */
    private void giveBirth(List<Animal> newLizards)
    {
        // New lizards are born into adjacent locations.
        // Get a list of adjacent free locations.
        // Only female lizards can give birth - they can mate with a random male in adjacent location
        if(getIsMale() == false){ 
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Lizard) {
                    Lizard lizard = (Lizard) animal;
                    if(lizard.getIsMale() && lizard.canBreed()) { 
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Lizard young = new Lizard(false, field, loc, randomBoolean());
                            if(randomBoolean())young.getDisease().setStepsUntilBetter(SICKNESS_STEPS); // if the randomizer gets true, we make the animal sick 
                            newLizards.add(young);
                        }
                        return; //mate with the first seen suitable lizard only
                    }
                }
            }

        }
    } 

    /**
     * Look for grass adjacent to the current location.
     * Only the first piece of berry is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Berries) {
                Berries berries = (Berries) plant;
                if(berries.isAlive()) { 
                    berries.setDead();
                    setFoodLevel(BERRIES_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Spread the disease to the first adjcent non-sick animal of the same kind
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Lizard) {
                Lizard lizard = (Lizard) animal; //if this lizard is healthy, we spread the infection, if it is alreay ill, we move on to the next one
                if(!lizard.getDisease().isSick()) { 
                    lizard.getDisease().setStepsUntilBetter(SICKNESS_STEPS);
                    return;
                }
            }
        }
    }
}

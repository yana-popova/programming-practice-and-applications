import java.util.Random;

/**
 * There are a few types of weather, which get generated every few steps and last for another number of steps.
 *
 * @author Amanjit Somal and Yana Popova
 * @version 16/02/18
 */
public class Weather
{
    
    private int numberOfWeatherStyles; //we're gonna use it to generate random weather - so that when people add more weather types in the future, they make less changes in the code
    private WeatherTypes weather; //The different types of weather 
    
    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        numberOfWeatherStyles = 5;
    }
  
    /**
     * Generate a random weather 
     */
    public WeatherTypes generateWeather()
    {
        Random rand = new Random();
        int weather = rand.nextInt(5);
        switch(weather){
            case 0:
                return WeatherTypes.WINDY;  //when it's windy - diurnal can't move
            case 1:
                return WeatherTypes.FOGGY;  //when it's foggy - nocturnal animals can't move 
            case 2:
                return WeatherTypes.SNOWY;  //when it's snowy - all animals seek shelter and dont move
            case 3:
                return WeatherTypes.RAINY; //when it's rainy - the plants' growth rate goes up temporarily
            case 4: 
            default:
                return WeatherTypes.CALM;  //everything is normal when it is calm
        }
    }
    
}

import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * wolfes age, move, eat rabbits, and die.
 * 
 * @author David J. Barnes and Michael Kölling, Yana Popova and Amanjit Somal
 * @version 21.02.2018
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolfes (class variables).

    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 140;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 15;
    // If the animal is nocturnal or not
    private static final boolean IS_NOCTURNAL = true;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 13;
    // The duration of an illness of a wolf
    private static final int SICKNESS_STEPS = 2;

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location, boolean isMale)
    {
        super(field, location, isMale);
        if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
            super.setFoodLevel(rand.nextInt(RABBIT_FOOD_VALUE));
        }
        else {
            super.setAge(0);
            super.setFoodLevel(RABBIT_FOOD_VALUE);
        }
    }

    /**
     * Return the breeding age of this wolf
     * @return The breeding age of this wolf
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }

    /**
     * Return the steps in which the wolf is sick
     * @return The steps in which the wolf is sick
     */
    public int getSicknessSteps(){
        return SICKNESS_STEPS;
    }

    /**
     * Return the max age of this wolf
     * @return The max age of this wolf
     */
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Return the breeding probability of this wolf
     * @return The breeding probability of this wolf
     */
    public double getBreedingProbability(){
        return BREEDING_PROBABILITY;
    }

    /**
     * Return the max litter size of this wolf
     * @return The max litter size of this wolf
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * Return if the wolf is nocturnal
     * @return if the wolf is nocturnal
     */
    public boolean getIsNocturnal(){
        return IS_NOCTURNAL;
    }

    /**
     * This is what the wolf does most of the time: it hunts for
     * rabbits. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newwolfes A list to return newly born wolfes.
     */
    public void act(List<Animal> newWolves)
    {
        incrementHunger();
        getDisease().manageHealth();

        if(isAlive()) {
            giveBirth(newWolves);  
            spreadDisease();
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    setFoodLevel(RABBIT_FOOD_VALUE);
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * Only female wolfes can give birth - they mate with the first suitable adjacent male
     * @param newwolfes A list to return newly born wolfes.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New wolfes are born into adjacent locations.
        // Get a list of adjacent free locations.
        // Only female wolfes can give birth - they can mate with a random male in adjacent location
        if(getIsMale() == false){ 
            Field field = getField();
            List<Location> free = field.getFreeAdjacentLocations(getLocation());
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Wolf) {
                    Wolf wolf = (Wolf) animal;
                    if(wolf.getIsMale() && wolf.canBreed()) { 
                        int births = breed();
                        for(int b = 0; b < births && free.size() > 0; b++) {
                            Location loc = free.remove(0);
                            Wolf young = new Wolf(false, field, loc, randomBoolean());
                            if(randomBoolean())young.getDisease().setStepsUntilBetter(SICKNESS_STEPS); // if the randomizer gets true, we make the animal sick 
                            newWolves.add(young);
                        }
                        return; //mate with the first seen suitable wolf only
                    }
                }
            }

        }
    }   

    /**
     * Spread the disease to the first adjcent non-sick animal of the same kind
     */
    private void spreadDisease()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Wolf) {
                Wolf wolf = (Wolf) animal; //if this wolf is healthy, we spread the infection, if it is alreay ill, we move on to the next one
                if(!wolf.getDisease().isSick()) { 
                    wolf.getDisease().setStepsUntilBetter(SICKNESS_STEPS);
                    return;
                }
            }
        }
    }
}

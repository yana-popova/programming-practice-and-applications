import java.util.Random;  
import java.util.List;

/**
 * A simple model of grass.
 * The grass ages, dies and breeds.
 *
 *@author Amanjit Somal and Yana Popova
 * @version 19.02.2018
 */
public class Grass extends Plant
{
    // Characteristics shared by all grass (class variables).
    
    // The likelihood of a grass breeding.
    private static final double GRASS_PROBABILITY = 0.85;    
    // The age to which a grass can live.
    private static final int MAX_AGE = 7;
    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 2;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 6;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Boolean randomAge, Field field, Location location)
    {
        super(field, location);
       if(randomAge) {
            super.setAge(rand.nextInt(MAX_AGE));
        }
        else {
            super.setAge(0);
        }
    }

    /**
     * Return the breeding age of the grass
     * @return The breeding age of the grass
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * Return the max age of the grass
     * @return The max age of the grass
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
     /**
     * Return the max child size of the grass
     * @return The max child size of the grass
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }
    
    /**
     * Return the breeding probability of the grass
     * @return The breeding probability of the grass
     */
    public double getBreedingProbability(){
        return GRASS_PROBABILITY;
    }
      
    /**
     * This is what the grass does most of the time
     * In the process, it might breed
     * or die of old age.
     * @param field The field currently occupied.
     * @param newPlants A list to return newly born plants.
     * 
     */
    public void act(List<Plant> newPlants){
        if(isAlive()) {
            giveBirth(newPlants);            
            Location newLocation = getField().freeAdjacentLocation(getLocation());
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
     
        }
    }   

    /**
     * Check whether or not the grass is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newPlants A list to return newly born plants.
     */
    private void giveBirth(List<Plant> newPlants){
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Grass(false, field, loc);
            newPlants.add(young);
        }
    }  
}
import java.util.Random; 
import java.util.List;

/**
 * Abstract class Plant -  * A class representing shared characteristics of plants.
 *
 * @author Amanjit Somal and Yana Popova
 * @version 19.02.2018
 */
public abstract class Plant extends Organism
{
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(Field field, Location location)
    {
        super(field, location);  

    }
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlant A list to receive newly born plants.
     */
    abstract public void act(List<Plant> newPlants);
}
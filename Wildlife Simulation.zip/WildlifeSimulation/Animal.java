import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 * @author David J. Barnes, Michael Kölling, Amanjit Somal, Yana Popova
 * @version 10/02/18
 */
public abstract class Animal extends Organism
{

    // The animal's food level, which is increased by eating plants or prey animals.
    private int foodLevel; 
    // The animal's sex
    private boolean isMale;
    // The illness of the animal
    private Disease disease;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean isMale)
    {
        super(field, location);
        foodLevel = 0;
        this.isMale = isMale;
        disease = new Disease(0);
    }

    /**
     * Return if the animal is nocturnal
     * @return true if the animal is nocturnal, false otherwise
     */
    abstract protected boolean getIsNocturnal();

    /**
     * Return the duration of an animals's sickness
     * @return The duration of an animals's sickness
     */
    abstract protected int getSicknessSteps();

    /**
     * Return the disease of the animal
     * @return The disease of the animal
     */
    public Disease getDisease(){
        return disease;
    }

    /**
     * Return if this animal is male or not
     * @return True if the animal is male, false otherwise
     */
    public boolean getIsMale(){
        return isMale;
    }

    /**
     * Return the food level of this animal
     * @return The food level of this animal
     */
    public int getFoodLevel(){
        return foodLevel;
    }

    /**
     * Set the food level of this animal
     * @param The food level of this animal
     */
    public void setFoodLevel(int foodLevel){
        this.foodLevel = foodLevel;
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Generate an random boolean // for the disease 
     */
    public boolean randomBoolean()
    {
        int randomNumber = rand.nextInt(2);
        if(randomNumber == 1) return true; 
        else return false;
    }

    /**
     * Make this animal more hungry. This could result in the animal's death.
     */
    public void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }

    }
}


/**
 * Keeps track of the time of the day and returs whether it is day or not - it is day from 6:00 to 18:00.
 *
 * @author Amanjit Somal and Yana Popova
 * @version 13/02/18
 */
public class Time
{
    private int hour;

    /**
     * Constructor for objects of class Time
     */
    public Time()
    {
        hour = 0;
    }

    /**
     * Return the hour
     * @return The hour
     */
    public int getHour(){
        return hour;
    }
    
    /**
     * Calculate whether it is day or night
     * @return Day or night
     */
    public String dayOrNight(){
        if(isDay()) return new String("Day");
        return new String("Night");
    }
    
    /**
     * Set the hour
     * @param The new hour value
     */
    public void setHour(int hour){
        this.hour = hour;
    }
    
    /**
     * Incrememnt the hours
     */
    public void incrementHour()
    {
        if(hour<23) hour++;
        else hour=0;
    }
    
    /**
     * Checks if it is day or night
     * @return True if it is day, false otherwise
     */
    public boolean isDay()
    {
        if(hour>6 && hour<=18) return true;
        return false;
    }
}

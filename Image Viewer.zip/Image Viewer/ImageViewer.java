/**
 * ImageViewer is a class that displays and manipulates images from an album, depending on which button the user has pressed. 
 * It calls the ImageViewerGUI class when something needs to be displayed.
 * It also calculates other statistics information.
 * 
 * @author Yana Popova and Michael Kölling
 * @version 1.0
 */

// Yana Popova, Student ID Number: 1705057
public class ImageViewer
{   
    //fields:
    private ImageViewerGUI gui;     // the Graphical User Interface
    private Album album;  
    
    private int currentImageIndex; // It keeps the index of the currently displayed image
    private Image currentImage; // The image that is currently displayed
    private int viewedImagesCounter; // It counts the number of images we have viewed so far
    private int viewedImagesWidth; // It calculates the width of all the viewed images
    
    /**
     * Create an ImageViewer and display its GUI on screen.
     */
    public ImageViewer()
    {
        gui = new ImageViewerGUI(this);
        album = new Album("images");
        
        // When the image viewer is started, the first image is automatically displayed 
        currentImageIndex = 0;
        displayImageWithNameAndStatus();
        // Since the first image is displayed automatically and we always see it, the minimum value that we should assign to the viewedImagesCounter variable is 1
        viewedImagesCounter = 1; 
        // Since the first image is displayed automatically and we always see it, the minimum value that we should assign to the viewedImagesWidth variable is the width of the first image
        viewedImagesWidth = currentImage.getWidth(); 
        
        gui.setImageSize(maxWidth(), maxHeight()); // Stop the resizing with every image change
    }

    /**
     * Display the next image
     */
    public void nextImage()
    {
        currentImageIndex++;
        if(currentImageIndex == album.numberOfImages()){
            currentImageIndex = 0; // Returns to the first image when we have reached the last one and click "Next"
        }
        displayImageWithNameAndStatus();
        viewedImagesCounter++;
        viewedImagesWidth += currentImage.getWidth();        
    }

    /**
     * Display the previous image
     */
    public void previousImage()
    {
        currentImageIndex--;
        if(currentImageIndex == -1){
            currentImageIndex = album.numberOfImages() - 1; // Goes to the last image when we have reached the first one and click "Prevoius"
        }
        displayImageWithNameAndStatus();
        viewedImagesCounter++;
        viewedImagesWidth += currentImage.getWidth();        
    }

    /**
     * Apply the fisheye effect to the current image
     */
    public void fishEye()
    {
        currentImage.fishEye();
        displayImageWithNameAndStatus();
    }
    
    // extra challenge
    /**
     * Return a String with the statistics information
     * @return The statistics string
     */
    public String showStatistics()
    {
        String statistics = "Number of images viewed: " + viewedImagesCounter + "\nAverage width: " + averageImageWidth();
        return statistics;
    }
    // end of extra challenge part
    
    /**
     * Display the current image with its name and status
     */
    public void displayImageWithNameAndStatus()
    {
        currentImage = album.getImage(currentImageIndex); 
        gui.showImage(currentImage); 
        gui.showName(currentImage.getName());
        gui.showStatus("Image size: width: " + currentImage.getWidth() + ", height: " + currentImage.getHeight());
    }
    
    /**
     * Find the number of images that have been viewed since the image viewer was started. Viewing the same image twice counts as 2 views. 
     * @return The number of images that have been viewed since the image viewer was started
     */
    public int getNumberOfImagesViewed() 
    {
        return viewedImagesCounter; //we have used the global variable as a counter in the previous methods and now we are just returning its value
    }
    
    /**
     * Find the average width of the images that have been viewed so far. 
     * Viewing the same image n-times counts as n-views and its width is counted n-times. 
     * @return The average width of the images that have been viewed so far 
     */
    public int averageImageWidth() 
    {
        //we have found the sum of the widths of all viewed images in the previous methods - if an image is viewed more than once(n times), we add its witdh to the sum n-times
        return viewedImagesWidth / viewedImagesCounter; 
    }
    
    /**
     * Find the maximum width of any of the images in the album 
     * @return The maximum width of the images in the album
     */
    public int maxWidth(){
        //in the beginning, the maximum width is the width of the first image
        int maximumWidth = album.getImage(0).getWidth(); 
        
        for(int i = 1; i < album.numberOfImages(); i++) {
            //if the current image has larger width than the maximum width
            if(maximumWidth < album.getImage(i).getWidth()) {
                maximumWidth = album.getImage(i).getWidth();
            }
        }
        return maximumWidth;
    }
    
    /**
     * Find the maximum height of any of the images in the album 
     * @return The maximum height of the images in the album
     */
    public int maxHeight(){
        //in the beginning, the maximum height is the height of the first image
        int maximumHeight = album.getImage(0).getHeight(); 
        
        for(int i = 1; i < album.numberOfImages(); i++) {
            //if the current image has larger height than the maximum height
            if(maximumHeight < album.getImage(i).getHeight()) {
                maximumHeight = album.getImage(i).getHeight();
            }
        }
        return maximumHeight;
    }

}

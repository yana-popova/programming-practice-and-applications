package slideshow;

/**
 *  
 * @author 
 * @version 
 */
public class ImageViewer
{    
    private ImageViewerGUI gui;     // the Graphical User Interface
    private Album album;
    
    /**
     * Create an ImageViewer and display its GUI on screen.
     */
    public ImageViewer()
    {
        gui = new ImageViewerGUI(this);
        album = new Album("images");
    }

    /**
     * 
     */
    public void nextImage()
    {
    }

    /**
     * 
     */
    public void previousImage()
    {
    }

    /**
     * 
     */
    public void fishEye()
    {
    }

}

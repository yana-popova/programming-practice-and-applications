
/**
 * Character holds and encapsulates the name, greeting and current location of the character.
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Character
{
    private String name;
    private String greeting; //the character will speak when the player first meets them
    private boolean neverMet; //if the player has met them or not
    private Room currentRoom; // the room the character is currently in
    
    /**
     * Constructor for objects of class Character
     */
    public Character(String name, String greeting, Room currentRoom, int timeBonus)     
    { 
        this.name = name;
        this.greeting = greeting;
        neverMet = true; //if they meet the player this flag will become false and they will not greet the player twice
        this.currentRoom = currentRoom;
    }

    /**
     * Return the name of the character
     * @return the name of the character
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Return the greeting of the character
     * @return the greeting of the character
     */
    public String getGreeting()
    {
        return greeting;
    }
    
    /**
     * Check whether the player and the character have aready met
     * @return true if they have never met, false otherwise
     */
    public boolean getNeverMet()
    {
        return neverMet;
    }
    
    /**
     * Set up whether the player and the character have aready met
     * @param neverMet Whether they hace met or not
     */
    public void setNeverMet(boolean neverMet)
    {
        this.neverMet = neverMet;
    }
    
    /**
     * Return the room the character is in
     * @return The room the character is in
     */
    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    /**
     * Set the room the character is in
     * @param currentRoom The room the character shoud be in
     */
    public void setCurrentRoom(Room currentRoom)
    {
        this.currentRoom = currentRoom;
    }
}

import java.util.ArrayList;
import java.util.Stack;
/**
 * Represents the functionality of theplayer in the game - constructs his route
 * through the rooms, implements taking and leaving an item, using a beamer and
 * returns which items the player holds. 
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Player
{
    // instance variables
    private int maxWeightToCarry; // the maximum weight the player can carry //moje da e konstanta
    private int currentWeightOfItems; // the current weight of the items that the player is carrying
    private ArrayList<Item> items; //the items the player is currently carrying
    private Room currentRoom; // the room the player is currently in
    private Stack<Room> route; //the sequence of the rooms that the player has been in
    private Room beamer; //when it charges it memorizes the room you are in and helps you go back to it
    
    //private int points; //
    
    /**
     * Constructor for objects of class Player
     * @param currentRoom The current room
     */
    public Player(Room currentRoom)
    {
        maxWeightToCarry = 40; 
        items = new ArrayList<>();
        this.currentRoom = currentRoom;
        route = new Stack<>();
        route.push(currentRoom);
    }
    
    /**
     * Return the curent room
     * @return The current room
     */
    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    /**
     * Set the curent room
     * @param currentRoom The current room
     */
    public void setCurrentRoom(Room currentRoom)
    {
        this.currentRoom = currentRoom;
        route.push(currentRoom);
    }
    
     /**
     * Return the sequence of the rooms the player has been in
     * @return The sequence of the rooms the player has been inside
     */
    public Stack<Room> getRoute()
    {
        return route;
    }
    
    /**
     * Put a room inside of the route of rooms that the player has been consecutively in
     * @return The current room
     */
    public void putRoom(Room room)
    {
        route.push(room);
    }

   /**
     * Go back to the previous room you have been to
     * @return If this is the first room
     */
    public boolean goBack()
    {
        if(!route.empty()){
            route.pop();
            if(!route.empty()){ 
                currentRoom = route.peek();
                if(route.size()==1) return true;
                return false;
            }
            else return true;
        } 
        return true;
    }
    
    /**
     * Find if the the room contains an item with this name
     * @param itemName The name of the item we are looking for
     */
    public Item findItemByNameInRoom(String itemName){
        Item itemToFind = null;
        for(Item item : currentRoom.getItemsInRoom()){
            if(item.getName().equals(itemName)){
                itemToFind = item;
                break;
            }
        }
        return itemToFind;
    }
    
    /**
     * Find if the the player holds an item with this name
     * @param itemName The name of the item we are looking for
     */
    public Item findItemByNameInPlayer(String itemName){
        Item itemToFind = null;
        for(Item item : items){
            if(item.getName().equals(itemName)){
                itemToFind = item;
                break;
            }
        }
        return itemToFind;
    }
    
    /**
     * Take an item and return a message if successful or not
     * @param  itemName The name of the item the player wants to take
     * @return A message if have successfully taken an item 
     */
    public String takeItem(String itemName)
    {
        String toReturn;
        Item itemToTake = findItemByNameInRoom(itemName);
        if(itemToTake == null) toReturn = "No such item in room";
        else{
            if(itemToTake.getCanPickUp() == true && (itemToTake.getWeight() + currentWeightOfItems <= maxWeightToCarry)){
                items.add(itemToTake);
                currentWeightOfItems += itemToTake.getWeight();
                currentRoom.removeItem(itemToTake);
                toReturn = "You successfully took the item!";
            }
            else{
                toReturn = "You could not take the item. You would go over the weight limit.";
            }
        }
        return toReturn;
    }
    
    /**
     * Leave an item in a room
     * @param  itemName The name of the item the player wants to leave in a room
     * @return A message that the player has left the item 
     */
    public String leaveItem(String itemName)
    {
        String toReturn;
        Item itemToLeave = findItemByNameInPlayer(itemName);
        if(itemToLeave==null) {
            toReturn = "You are not holding this item, so you cannot leave it.";
        }
        else{
            items.remove(itemToLeave);
            currentRoom.putItem(itemToLeave);
            currentWeightOfItems -= itemToLeave.getWeight();
            toReturn = "You left the item!";
        }
        return toReturn;
    }
    
    /**
     * Return a string of the items the player is currently carrying and their total weight
     * @return A string of the items the player is currently carrying
     */
    public String getItemsString()
    {
        String returnString = "Items:";
        int totalWeight = 0;
        for(Item item : items) {
            returnString += " " + item.getName();
            totalWeight += item.getWeight();
        }
        if(returnString.equals("Items:")){ //there are no items in this room
            returnString = new String("You are have no items at the moment");
        }
        else {
            returnString += "; Total weight: " + totalWeight;
        }
        //not System.out.println(returnString); - looking ahead
        return returnString;
    }
    
    /**
     * Charge the Beamer - memorizes the current room you are in
     */
    public void chargeBeamer(){
        beamer = currentRoom;
    }
    
    /**
     * Fire the Beamer - it takes you back to the room you were in when you charged it
     */
    public void fireBeamer(){
        currentRoom = beamer;
    }
}

import java.util.ArrayList;
/**
 * Write a description of class Player here.
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Player
{
    // instance variables - replace the example below with your own
    private int maxWeightToCarry; // the maximum weight the player can carry //moje da e konstanta
    private int currentWeightOfItems; // the current weight of the items that the player is carrying
    private ArrayList<Item> items; //the items the player is currently carrying
    private int points; //
    
    /**
     * Constructor for objects of class Player
     */
    public Player()
    {
        maxWeightToCarry = 40; 
        items = new ArrayList<>();
    }
    
    /**
     * Take an item and return a message if successful or not
     * @param  item The item the player wants to take
     * @return A message if have successfully taken an item 
     */
    public String takeItem(Item item)
    {
        String toReturn;
        if(item.getWeight() + currentWeightOfItems <= maxWeightToCarry){
            items.add(item);
            currentWeightOfItems += item.getWeight();
            toReturn = "You successfully took the item!";
        }
        else{
            toReturn = "You could not take the item. You would go over the weight limit.";
        }
        return toReturn;
    }
    
    /**
     * Leave an item
     * @param  item The item the player wants to leave
     * @return A message that the player has left the item 
     */
    public String leaveItem(Item item)
    {
        items.remove(item);
        currentWeightOfItems -= item.getWeight();
        String toReturn = "You left the item!";
        return toReturn;
    }
}

import java.util.Set;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  For each existing exit, the room 
 * stores a reference to the neighboring room.
 * 
 * @author Michael Kölling, David J. Barnes and Yana Popova
 * @version 2016.02.29
 */

public class Room 
{
    private String description;
    private HashMap<String, Room> exits;        // stores exits of this room.
    private ArrayList<Item> itemsInRoom;        // YANA stores the items inside the room
    private ArrayList<Character> charactersInRoom; //the characters inside the room
    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Room(String description) 
    {
        this.description = description;
        exits = new HashMap<>();
        itemsInRoom = new ArrayList<>(); //YANA
        charactersInRoom = new ArrayList<>();
    }

    /**
     * Define an exit from this room.
     * @param direction The direction of the exit.
     * @param neighbor  The room to which the exit leads.
     */
    public void setExit(String direction, Room neighbor) 
    {
        exits.put(direction, neighbor);
    }

    /**
     * @return The short description of the room
     * (the one that was defined in the constructor).
     */
    public String getShortDescription()
    {
        return description;
    }

    /**
     * Return a description of the room in the form:
     *     You are in the kitchen.
     *     Exits: north west
     * @return A long description of this room
     */
    public String getLongDescription()
    {
        return "You are " + description + ".\n" + getExitString();
    }

    /**
     * Return a string describing the room's exits, for example
     * "Exits: north west".
     * @return Details of the room's exits.
     */
    private String getExitString()
    {
        String returnString = "Exits:";
        Set<String> keys = exits.keySet();
        for(String exit : keys) {
            returnString += " " + exit;
        }
        return returnString;
    }

    /**
     * Return the room that is reached if we go from this room in direction
     * "direction". If there is no room in that direction, return null.
     * @param direction The exit's direction.
     * @return The room in the given direction.
     */
    public Room getExit(String direction) 
    {
        return exits.get(direction);
    }
    
    /**  YANA
     * Add an item into the room
     */
    public void putItem(Item item){
        itemsInRoom.add(item); //encapsulation - access to the private fields here is not allowed from another class
    }
    
    
    /**  YANA
     * Return a string describing the items in the room, for example
     * "Items: necklace sarcophagus".
     * @return String with the items in the room.
     */
    public String getItemsString(){
        String returnString = "Items:";
        for(Item item : itemsInRoom) {
            returnString += " " + item.getName();
        }
        if(returnString.equals("Items:")){ //there are no items in this room
            returnString = new String("There are no items in this room");
        }
        //System.out.println(returnString); - gledane w budeshteto
        return returnString;
    }
    
    /**  YANA
     * Add a character into the room
     */
    public void putCharacter(Character character){
        charactersInRoom.add(character); //encapsulation - access to the private fields here is not allowed from another class
    }
    
    /**  YANA
     * Remove a character from the room
     */
    public void removeCharacter(Character character){
        charactersInRoom.remove(character); //encapsulation - access to the private fields here is not allowed from another class
    }
    
    /**  YANA
     * Return a string describing the characters in the room, for example
     * "Characters: cat mummy".
     * @return String with the characters in the room.
     */
    public String getCharactersString(){
        String returnString = "Characters:";
        for(Character character : charactersInRoom) {
            returnString += " " + character.getName();
        }
        if(returnString.equals("Characters:")){ //there are no items in this room
            returnString = new String("There are no items in this room");
        }
        //System.out.println(returnString); - gledane w budeshteto
        return returnString;
    }
    
    
}


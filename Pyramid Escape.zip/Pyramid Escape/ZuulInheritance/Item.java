
/**
 * Item implements the .
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Item
{
    private String name; //the name of the Item
    private boolean canPickUp; //if the item can be picked up or not
    private int weight; //the weight of the item

    /**
     * Constructor for objects of class Item
     */
    public Item(String name, boolean canPickUp, int weight) //ще го ползвам ли някъде??
    {
        this.name = name;
        this.canPickUp = canPickUp;
        this.weight = weight;
    }

    /**
     * Return the name of the item
     * @return The name of the item
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Check whether the item can be picked up
     * @return Whether the item can be picked up
     */
    public boolean getCanPickUp()
    {
        return canPickUp;
    }
    
    /**
     * Return the weight of the item
     * @return The weight of the item
     */
    public int getWeight()
    {
        return weight;
    }
}

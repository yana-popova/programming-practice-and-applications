
/**
 * Write a description of class Character here.
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Character
{
    private String name;
    private String greeting; //the character will speak when the player first meets them
    private boolean neverMet; //if the player has met them or not
    //??? should it be an Item or a string
    private String itemForHelp; //the name of the item the character should be given in order to help
    private String help; //the helpful information the character can give

    /**
     * Constructor for objects of class Character
     */
    public Character(String name, String greeting, String itemForHelp, String help)     
    { 
        this.name = name;
        this.greeting = greeting;
        neverMet = true; //if they meet the player this flag will become false and they will not greet the player twice
        this.itemForHelp = itemForHelp;
        this.help = help;
    }

    /**
     * Return the name of the character
     * @return the name of the character
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Return the greeting of the character
     * @return the greeting of the character
     */
    public String getGreeting()
    {
        return greeting;
    }
    
    /**
     * Check whether the player and the character have aready met
     * @return true if they have never met, false otherwise
     */
    public boolean getNeverMet()
    {
        return neverMet;
    }
    
    /**
     * Return the name of the item the character should be given to help
     * @return the item the character should be given to help
     */
    public String getItemForHelp()
    {
        return itemForHelp;
    }
    
    /**
     * Return the helpful information the character can give
     * @return the helpful information the character can give
     */
    public String getHelp()
    {
        return help;
    }
    
    /**
     * Print out what item the character needs so that it can help you
     * @return the name of the item the character needs so that it can help you
     */
    public String requestItem()
    {
        return help;
    }
    
    public void move(){
        
    }
}

import java.util.HashMap;
/**
 * The class Map creates and positions everything inside the pyramid - 
 * the rooms, the items and the characters.
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Map
{
    private HashMap<String, Room> rooms; //all the rooms inside the pyramid

    /**
     * Constructor for objects of class Map
     */
    public Map()
    {
        rooms = new HashMap<>();
    }
    
    /**
     * Returns the collection of all the rooms in the pyramid
     * @return A collection of all the rooms in the pyramid
     */
    public HashMap<String, Room> getRooms(){
        return rooms;
    }

    /**
     * Create all the rooms and link their exits together.
     */
    public void createRooms(){
    
        Room kingsChamber, queensChamber, secretChamber, greatGallery, smallGallery, corridor, transporterRoom;
        
        // create the rooms
        kingsChamber = new Room("inside the King's chamber");
        corridor = new Room("inside the corridor");
        smallGallery = new Room("inside the Small Gallery");
        greatGallery = new Room("inside the Great Gallery");
        queensChamber = new Room("inside the Queen's chamber");
        secretChamber = new Room("inside the secter chamber");
        transporterRoom = new Room("inside the transporter room");
       
        // initialise room exits
        kingsChamber.setExit("east", corridor);
        
        corridor.setExit("east", smallGallery);
        corridor.setExit("west", kingsChamber);
        corridor.setExit("south", greatGallery);
        
        smallGallery.setExit("west", corridor);
        smallGallery.setExit("south", queensChamber);
        
        greatGallery.setExit("north", corridor);
        greatGallery.setExit("east", queensChamber);
        greatGallery.setExit("south", secretChamber);
        
        queensChamber.setExit("west", greatGallery);
        queensChamber.setExit("north", smallGallery);
        queensChamber.setExit("south", transporterRoom);
        
        secretChamber.setExit("north", greatGallery);
        secretChamber.setExit("east", transporterRoom);
        
        //we do not need to set exits to the transporter room because it 
        //magically transports the player to a random room
        
        //put them in the hashmap
        rooms.put("kingsChamber", kingsChamber);
        rooms.put("corridor", corridor);
        rooms.put("smallGallery", smallGallery);
        rooms.put("greatGallery", greatGallery);
        rooms.put("queensChamber", queensChamber);
        rooms.put("secretChamber", secretChamber);
        rooms.put("transporterRoom", transporterRoom);
    }
    
    /**
     * Return the first room the character is in, the start of the map
     * @return The first room the character is in, the start of the map
     */
    public Room startOfMap(){
        Room start = rooms.get("corridor"); //the first room, in which the player will be, is the corridor
        return start;
    }
    
    /**
     * Cerate all the items and allocate them in the rooms.
     */
    public void allocateItems(){
        //create the items
        Item amulet, bracelet, crook, earrings, hieroglyphs, jar, necklace, papyrus, sarcophagus, scarab;
        amulet = new Item("amulet", true, 10);
        bracelet = new Item("bracelet", true, 15);
        crook = new Item("crook", true, 20);
        earrings = new Item("earrings", true, 10);
        hieroglyphs = new Item("hieroglyphs", false, 100);
        jar = new Item("jar", false, 30);
        necklace = new Item("necklace", true, 30);
        papyrus = new Item("papyrus", true, 40);
        sarcophagus = new Item("sarcophagus", false, 500);
        scarab = new Item("scarab", false, 15);
        
        //allocate the items in the rooms
        rooms.get("kingsChamber").putItem(sarcophagus);
        rooms.get("kingsChamber").putItem(amulet);
        rooms.get("kingsChamber").putItem(crook);
        
        rooms.get("smallGallery").putItem(jar);
        
        rooms.get("queensChamber").putItem(bracelet);
        rooms.get("queensChamber").putItem(earrings);
        rooms.get("queensChamber").putItem(necklace);
        
        rooms.get("greatGallery").putItem(hieroglyphs);
        rooms.get("greatGallery").putItem(scarab);
        
        rooms.get("secretChamber").putItem(papyrus);
    }
    
    /**
     * Cerate all the characters and allocate them in the rooms.
     */
    public void allocateCharacters(){
        //create the items
        Character mummy, sphynx, cat, seth, anubis;
        mummy = new Character("Mummy", "I am the mighty Mummy, give me the crook and I will help you!", "crook", "h");
        sphynx = new Character("Sphynx", "I am the Sphynx, give me the amulet and I will help you!", "amulet", "h");
        
        //allocate the characters in the rooms
        rooms.get("kingsChamber").putCharacter(mummy);

    }
}

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;
/**
 *  This class is the main class of the "Pyramid Escape" application. 
 *  "Pyramid Escape" is a text based adventure game.  Users 
 *  can enter commands and control the player, who is trapped in the
 *  pyramid and wants to escape. 
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it initializes the
 *  Map class, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling, David J. Barnes and Yana Popova
 * @version 01/12/17
 */

public class Game 
{
    private Parser parser;
    private Player player;
    private Room currentRoom;
    private Map map;
        
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        map = new Map();
        map.createRooms();
        map.allocateItems();
        map.allocateCharacters();
        player = new Player(map.startOfMap());
        parser = new Parser();
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
        int timer = 40; // it counts the number of remaining commands - if it becomes 0, you lose
        boolean finished = false;
        while (! finished && timer>0) {
            moveAllCharacters();
            System.out.println(player.getCurrentRoom().getCharactersString());    
            Command command = parser.getCommand();
            finished = processCommand(command);
            timer--;
            String itemsInCorridor = map.getRooms().get("corridor").getItemsString();
            if(itemsInCorridor.contains("amulet")&&itemsInCorridor.contains("bracelet")&&itemsInCorridor.contains("crook")&&itemsInCorridor.contains("earrings")&&itemsInCorridor.contains("necklace")&&itemsInCorridor.contains("scroll")){
                System.out.println("You win!");
                break;
            }
        }
        if(timer == 0) System.out.println("Your time is up. You lose!");
        System.out.println("Thank you for playing.  Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to Pyramid Escape!");
        System.out.println("You are an archeologist trapped in a magical Pyramid. Escape before your time is up!");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println(player.getCurrentRoom().getLongDescription());
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;
        CommandWord commandWord = command.getCommandWord();
        
        switch(commandWord){
            case UNKNOWN:
                System.out.println("I don't know what you mean...");
                break;
            case HELP:
                printHelp();
                break;
            case GO:
                goRoom(command);
                break;
            case QUIT:
                wantToQuit = quit(command);
                break;
            case ITEMS:
                System.out.println(player.getItemsString());
                break;
            case TAKE:
                takeItem(command);
                break;
            case LEAVE:
                leaveItem(command);
                break;
            case BACK:
                goBack(command);
                break;
            case CHARGE:
                charge();
                break;
            case FIRE:
                fire();
                break;
        }
        // else command not recognised.
        return wantToQuit;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("Find and take all items that you can pick up and are ");
        System.out.println("not keys into the corridor, before your time is up!");
        System.out.println("If you don't succeed you will remain in the Pyramid forever...");
        System.out.println();
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    /**
     * Take a specified item
     * @param command The command that has been entered for taking an item
     */
    private void takeItem(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to take...
            System.out.println("Take what?");
            return;
        }

        String itemToTake = command.getSecondWord();
        String itemTakenMessage = player.takeItem(itemToTake);
        System.out.println(itemTakenMessage);
   
    }
    
    /**
     * Leave a specified item in a room
     * @param command The command that has been entered for leaving an item in a room
     */
    private void leaveItem(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know what to leave...
            System.out.println("Leave what?");
            return;
        }

        String itemToLeave = command.getSecondWord();
        String itemLeftMessage = player.leaveItem(itemToLeave);
        System.out.println(itemLeftMessage);
   
    }
    
    /** 
     * Try to in to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     * @param command The command that has been entered to go to another room
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("Go where?");
            return;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = player.getCurrentRoom().getExit(direction);

        //if there is no room in this direction
        if (nextRoom == null) {
            System.out.println("There is no door!");
        } //Challenge-transporter room
        else if(nextRoom == map.getRooms().get("transporterRoom")) { // if you are in the transporter room, you go to a random room
            //we make the HashMap into an ArrayList; whe then take a random index from it and make the room that has this index our current room
            ArrayList<Room> roomList = new ArrayList<Room>(map.getRooms().values());
            roomList.remove(map.getRooms().get("transporterRoom")); //so that we will not go to the transporter room again when we go to a random room
            Random rand = new Random();
            int randomIndex = rand.nextInt(roomList.size());
            player.setCurrentRoom(roomList.get(randomIndex));
            System.out.println(player.getCurrentRoom().getLongDescription());
        }
        else {
            player.setCurrentRoom(nextRoom);
            System.out.println(player.getCurrentRoom().getLongDescription());
        }
    }

    /** 
     * Go back to the rooms you have been in
     * @param command The command that has been entered to go back
     */
    private void goBack(Command command) 
    {
        //if there is a wrong command - anything that is not "back" - like "back back" or "back word"
        if(!command.hasSecondWord()) {
            boolean begining = player.goBack();
            System.out.println(player.getCurrentRoom().getLongDescription());
            if(begining == true){
                System.out.println("This is the first room you have ever been to.");
            }
        }
        else System.out.println("Invalid back command");
        
    }
    
    /** 
     * "Charge" was entered. The room is being remembered by the Beamer
     * 
     */
    private void charge() 
    {
        player.chargeBeamer();
    }
    
    /** 
     * "fire" was entered. The player goes to the room they were in when the beamer was charged
     * 
     */
    private void fire() 
    {
        player.fireBeamer();
        System.out.println(player.getCurrentRoom().getLongDescription());
    }
    
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
    
    /**
     * If the characters meeth eith the player
     */
    private void meet(Character character){
        if(player.getCurrentRoom() == character.getCurrentRoom() && character.getNeverMet() == true) {
            System.out.println(character.getGreeting());
            character.setNeverMet(false);
        }
    }
    
   /**
     * The characters' movement - all characters move in a random room(or stay in the same room) every time the player enters a command
     * @param character The character that has to move
     */
    private void moveCharacter(Character character){
        ArrayList<Room> roomList = new ArrayList<Room>(map.getRooms().values());
        roomList.remove(map.getRooms().get("transporterRoom")); //so that they dont go to the transporter room as we cannot meet them there
        Random rand = new Random(); 
        int randomIndex = rand.nextInt(roomList.size());
        character.getCurrentRoom().removeCharacter(character);
        character.setCurrentRoom(roomList.get(randomIndex));
        roomList.get(randomIndex).putCharacter(character);
        meet(character);
    }
    
    /**
     * Moves all characters in the game in a random room
     */
    private void moveAllCharacters(){
        for(Character character : map.getCharacters()){
            moveCharacter(character);
        }
    }
}

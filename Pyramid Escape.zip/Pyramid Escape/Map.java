import java.util.HashMap;
import java.util.ArrayList;
/**
 * The class Map creates and positions everything inside the pyramid - 
 * the rooms, the items and the characters.
 *
 * @author Yana Popova
 * @version 01/12/17
 */
public class Map
{
    private HashMap<String, Room> rooms; //all the rooms inside the pyramid
    private ArrayList<Character> characters; //all the characters inside the pyramid

    /**
     * Constructor for objects of class Map
     */
    public Map()
    {
        rooms = new HashMap<>();
        characters = new ArrayList<>();
    }
    
    /**
     * Returns the collection of all the rooms in the pyramid
     * @return A collection of all the rooms in the pyramid
     */
    public HashMap<String, Room> getRooms(){
        return rooms;
    }
    
    /**
     * Returns the collection of all the characters in the pyramid
     * @return A collection of all the characters in the pyramid
     */
    public ArrayList<Character> getCharacters(){
        return characters;
    }

    /**
     * Create all the rooms and link their exits together.
     */
    public void createRooms(){
    
        Room kingsChamber, queensChamber, secretChamber, greatGallery, smallGallery, corridor, transporterRoom;
        
        // create the rooms
        kingsChamber = new Room("inside the King's chamber");
        corridor = new Room("inside the corridor");
        smallGallery = new Room("inside the Small Gallery");
        greatGallery = new Room("inside the Great Gallery");
        queensChamber = new Room("inside the Queen's chamber");
        secretChamber = new Room("inside the secret chamber");
        transporterRoom = new Room("inside the transporter room");
       
        // initialise room exits
        kingsChamber.setExit("east", corridor);
        
        corridor.setExit("east", smallGallery);
        corridor.setExit("west", kingsChamber);
        corridor.setExit("south", greatGallery);
        
        smallGallery.setExit("west", corridor);
        smallGallery.setExit("south", queensChamber);
        
        greatGallery.setExit("north", corridor);
        greatGallery.setExit("east", queensChamber);
        greatGallery.setExit("south", secretChamber);
        
        queensChamber.setExit("west", greatGallery);
        queensChamber.setExit("north", smallGallery);
        queensChamber.setExit("south", transporterRoom);
        
        secretChamber.setExit("north", greatGallery);
        secretChamber.setExit("east", transporterRoom);
        
        //we do not need to set exits to the transporter room because it 
        //magically transports the player to a random room
        
        //put them in the hashmap
        rooms.put("kingsChamber", kingsChamber);
        rooms.put("corridor", corridor);
        rooms.put("smallGallery", smallGallery);
        rooms.put("greatGallery", greatGallery);
        rooms.put("queensChamber", queensChamber);
        rooms.put("secretChamber", secretChamber);
        rooms.put("transporterRoom", transporterRoom);
    }
    
    /**
     * Return the first room the character is in, the start of the map
     * @return The first room the character is in, the start of the map
     */
    public Room startOfMap(){
        Room start = rooms.get("corridor"); //the first room, in which the player will be, is the corridor
        return start;
    }
    
    /**
     * Cerate all the items and allocate them in the rooms.
     */
    public void allocateItems(){
        //create the items
        Item amulet, bracelet, crook, earrings, hieroglyphsStone, jar, necklace, scroll, sarcophagus, scarab;
        amulet = new Item("amulet", "a magical amulet", true, 10);
        bracelet = new Item("bracelet", "an ornate golden bracelet", true, 15);
        crook = new Item("crook", "the Pharaoh's crook, symbol of power", true, 20);
        earrings = new Item("earrings", "golden earrings", true, 10);
        hieroglyphsStone = new Item("hieroglyphs", "ancient stone inscribed with hieroglyphs", false, 100);
        jar = new Item("jar", "a jar with the organs of the mummy", false, 30);
        necklace = new Item("necklace", "a beautiful golden necklace", true, 30);
        scroll = new Item("scroll", "a scroll with a magical spell", true, 40);
        sarcophagus = new Item("sarcophagus", "the mighty Pharaoh's resting place", false, 500);
        scarab = new Item("scarab", "an old figure of a scarab", false, 15);
        
        //allocate the items in the rooms
        rooms.get("kingsChamber").putItem(sarcophagus);
        rooms.get("kingsChamber").putItem(amulet);
        rooms.get("kingsChamber").putItem(crook);
        
        rooms.get("smallGallery").putItem(jar);
        
        rooms.get("queensChamber").putItem(bracelet);
        rooms.get("queensChamber").putItem(earrings);
        rooms.get("queensChamber").putItem(necklace);
        
        rooms.get("greatGallery").putItem(hieroglyphsStone);
        rooms.get("greatGallery").putItem(scarab);
        
        rooms.get("secretChamber").putItem(scroll);
    }
    
    /**
     * Cerate all the characters and allocate them in the rooms.
     */
    public void allocateCharacters(){
        //create the items
        Character mummy, sphynx, cat, anubis;
        mummy = new Character("Mummy", "I am the mighty Mummy", rooms.get("kingsChamber"), 3);
        sphynx = new Character("Sphynx", "I am the ancient Sphynx", rooms.get("greatGallery"), 4);
        cat = new Character("Cat", "Miauu", rooms.get("queensChamber"), 5);
        anubis = new Character("Anubis", "I am the god of the dead, Anubis", rooms.get("secretChamber"), -3);
        
        //allocate the characters in the rooms
        rooms.get("kingsChamber").putCharacter(mummy);
        rooms.get("greatGallery").putCharacter(sphynx);
        rooms.get("queensChamber").putCharacter(cat);
        rooms.get("secretChamber").putCharacter(anubis);
        
        //put the characters in the arraylist:
        characters.add(mummy);
        characters.add(sphynx);
        characters.add(cat);
        characters.add(anubis);

    }
}
